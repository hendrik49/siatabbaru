<?php

$this->breadcrumbs=array(
	'Album Manager'=>array('index'),
	$model->ID,
);

?>

<h2 class="h-view">Lihat Gambar <?php echo $model->NamaGambar; ?></h2>
<br><br>
<?php $this->widget('zii.widgets.CDetailView', array(
	'cssFile'=>Yii::app()->baseUrl . '/css/detailview/styles.css',
	'data'=>$model,
	'attributes'=>array(	
		array(
			'name'=>'Tanggal',
			'value'=>date('d / m / Y', $model->Tanggal),
		),
		'NamaGambar',
		'status',
		array(
			'name'=>'Foto Kantor Unit Kerja',
			'type'=>'raw',
			'value'=>'<img width="400px" height="300px" src="'.Yii::app()->request->baseUrl.'/images/Kegiatan/'.$model->Link.'"/>',
		),
	),
)); ?>
